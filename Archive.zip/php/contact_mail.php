<?php
	
require('class.phpmailer.php');

    $nombre     	= $_POST["nombre"];
    $empresa     	= $_POST["empresa"];
    $tel  		   	= $_POST["tel"];
    $puesto   		= $_POST["puesto"];
    $email        	= $_POST["email"];
    $mensaje		= $_POST["mensaje"];
	
	//email body
    $message_body = 
    "<br/> NOMBRE: ".$nombre." \n<br/>  
    EMAIL: ".$email."\n <br/> 
    TELÉFONO: ".$tel."\n <br/> 
    PUESTO: ".$puesto."\n <br/> 
    EMPRESA: ".$empresa. "\n <br/> 
    MENSAJE: ".$mensaje. "\n\n <br/> ";

	$mail = new PHPMailer();
	$mail->IsSMTP();
	$mail->SMTPDebug = 0;
	$mail->SMTPAuth = TRUE;
	$mail->SMTPSecure = "ssl";
	$mail->Port     = 465;
	$mail->Username = "no-reply@sypysa.com.mx";
	$mail->Password = "noreply123987";
	$mail->Host     = "server.orogam.net";
	$mail->Mailer   = "smtp";
	$mail->SetFrom("no-reply@sypysa.com.mx", "sypysa");
	$mail->AddAddress("sypysa@sypysa.com.mx");
	$mail->AddAddress("ventasweb@sypysa.com.mx");
	$mail->addBCC("forms.marketify@gmail.com");
	$mail->Subject = "Contacto desde sypysa.com.mx";
	$mail->WordWrap   = 80;
	$mail->MsgHTML($message_body);
	$mail->IsHTML(true);

if ($mail->Send()){
	echo "Gracias su mensaje ha sido enviado, nos contactaremos con usted a la brevedad.";
} else {
	echo "Ha ocurrido un error, por favor llene de nuevo el formulario.";
}
?>