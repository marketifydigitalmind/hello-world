<?php
require('class.phpmailer.php');

	$popname    	= $_POST["popnombre"];
    $popemail      	= $_POST["popemail"];
    $poptel     	= $_POST["poptel"];
    $popempresa    	= $_POST["popempresa"];
    $poppuesto      = $_POST["poppuesto"];
    $popmensaje		= $_POST["popmensaje"];
    $popidioma		= $_POST["popidioma"];
    
    $mensaje = 
    "<br/> NOMBRE: ".$popname." \n<br/> 
    EMAIL: ".$popemail."\n <br/> 
    TELÉFONO: ".$poptel."\n <br/> 
    EMPRESA: ".$popempresa. "\n <br/> 
    PUESTO: ".$poppuesto. "\n <br>
    MENSAJE: ".$popmensaje."\n";
    
    $mail = new PHPMailer();
	$mail->IsSMTP();
	$mail->SMTPDebug = 0;
	$mail->SMTPAuth = TRUE;
	$mail->SMTPSecure = "ssl";
	$mail->Port     = 465;
	$mail->Username = "no-reply@sypysa.com.mx";
	$mail->Password = "noreply123987";
	$mail->Host     = "server.orogam.net";
	$mail->Mailer   = "smtp";
	$mail->SetFrom("no-reply@sypysa.com.mx", "sypysa");
	$mail->AddAddress("sypysa@sypysa.com.mx");
	$mail->AddAddress("ventasweb@sypysa.com.mx");
	$mail->addBCC("forms.marketify@gmail.com");
	$mail->Subject = "Contacto desde sypysa.com.mx popup";
	$mail->WordWrap   = 80;
	$mail->MsgHTML($mensaje);
	$mail->IsHTML(true);
	
	if ($mail->Send()){
		echo "Gracias, ahora puedes descargar nuestro currículum:";
		if ($popidioma == "esp") {
			echo '<br><br><a class="btn aqua" href="SYPYSAENG.pdf" target="_blank"> Español </a>';
		}
		if ($popidioma == "eng") {
			echo '<br><br><a class="btn aqua" href="SYPYSAENG.pdf" target="_blank"> English </a>';
		}
		if ($popidioma == "jap") {
			echo '<br><br><a class="btn aqua" href="SYPYSAENG.pdf" target="_blank"> 日本の </a>';
		}
	}
	else {
		echo "Ha ocurrido un error, por favor llene de nuevo el formulario.";
	}

?>