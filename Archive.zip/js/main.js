$(document).ready(function (e){
	
$("#contacto").on('submit',(function(e){
	e.preventDefault();
	var valid;
	valid = validateContact();
	if(valid) {
		$.ajax({
		url: "php/contact_mail.php",
		type: "POST",
		data:  new FormData(this),
		contentType: false,
		cache: false,
		processData:false,
		success: function(data){
		$("#resultado").html(data);
		window.location.href = 'gracias.html';
		},
		error: function(){}
		});
	}
}));

function validateContact() {
	var valid = true;
	$(".form-control").css('background-color','');
	$(".mail-info").html('');
	
	if(!$("#nombre").val()) {
		$("#nombre-info").html("(required)");
		$("#nombre").css('background-color','#FFFFDF');
		valid = false;
	}
	if(!$("#empresa").val()) {
		$("#empresa-info").html("(required)");
		$("#empresa").css('background-color','#FFFFDF');
		valid = false;
	}
	if(!$("#email").val()) {
		$("#email-info").html("(required)");
		$("#email").css('background-color','#FFFFDF');
		valid = false;
	}
	if(!$("#email").val().match(/^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/)) {
		$("#email-info").html("(invalid)");
		$("#email").css('background-color' , '#ff7f7f');
		$("#correo").text("Por favor, ingrese un correo válido.");
		$("#email").val('');
		valid = false;
	}
	if(!$("#tel").val()) {
		$("#tel-info").html("(required)");
		$("#tel").css('background-color','#FFFFDF');
		valid = false;
	}
	if(!$("#puesto").val()) {
		$("#puesto-info").html("(required)");
		$("#puesto").css('background-color','#FFFFDF');
		valid = false;
	}
	return valid;
}

$("#pop-contact").on('submit',(function(e){
	e.preventDefault();
	var valid;
	var resultado = $("#result");
	valid = validateContactPop();
	if(valid) {
		$.ajax({
		url: "php/popcontact.php",
		type: "POST",
		data:  new FormData(this),
		contentType: false,
		cache: false,
		processData:false,
		success: function(data){
		$("#popresult").html(data);
		$("#pop-contact").css('display','none');
		$(".pop-title").css('display','none');
		$("#descargar").css('display','block');
		$("input:radio[name=popidioma]").change(
			function (){
				if ( $(this).is(':checked') && $(this).val() == 'esp' ){
					$("#espanol").css('display','block');
				}
				if ( $(this).is(':checked') && $(this).val() == 'eng' ){
					$("#english").css('display','block');
				}
				if ( $(this).is(':checked') && $(this).val() == 'jap' ){
					$("#japan").css('display','block');
			}
		});
		},
		error: function(){}
		});
	}
}));

function validateContactPop() {
	var valid = true;
	$(".form-control").css('background-color','');
	$(".mail-info").html('');
	
	if(!$("#popnombre").val()) {
		$("#popnombre-info").html("(required)");
		$("#popnombre").css('background-color','#aaa');
		valid = false;
	}
	if(!$("#popemail").val()) {
		$("#popemail-info").html("(required)");
		$("#popemail").css('background-color','#aaa');
		valid = false;
	}
	if(!$("#popemail").val().match(/^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/)) {
		$("#popemail-info").html("(invalid)");
		$("#popemail").css('background-color' , '#ff7f7f');
		$("#pop-correo").text("Por favor, ingrese un correo válido.");
		$("#popemail").val('');
		valid = false;
	}
	if(!$("#poptel").val()) {
		$("#poptel-info").html("(required)");
		$("#poptel").css('background-color','#aaa');
		valid = false;
	}
	if(!$("#popempresa").val()) {
		$("#popempresa-info").html("(required)");
		$("#popempresa").css('background-color','#aaa');
		valid = false;
	}
	if(!$("#poppuesto").val()) {
		$("#poppuesto-info").html("(required)");
		$("#poppuesto").css('background-color','#aaa');
		valid = false;
	}
	if(!$("#poppuesto").val()) {
		$("#poppuesto-info").html("(required)");
		$("#poppuesto").css('background-color','#aaa');
		valid = false;
	}
	if(!$("input[name='popidioma']:checked").val()) {
		$("#pop-idioma").text("Por favor, selecciona un idioma.");
		valid = false;
	}
	return valid;
}

	var msg="";
	var elements = document.getElementsByTagName("INPUT");
	
	for (var i = 0; i < elements.length; i++) {
	   elements[i].oninvalid =function(e) {
	        if (!e.target.validity.valid) {
	        switch(e.target.id){
	            case 'popnombre' : 
	            e.target.setCustomValidity("Ingresa tu nombre.");break;
	            case 'popempresa' : 
	            e.target.setCustomValidity("Nombre de la empresa.");break;
	            case 'poptel' : 
	            e.target.setCustomValidity("Teléfono 10 dígitos.");break;
	            case 'popemail' : 
	            e.target.setCustomValidity("Ingresa un email válido.");break;
	            case 'poppuesto' : 
	            e.target.setCustomValidity("Ingresa tu puesto.");break;
	        default : e.target.setCustomValidity("");break;
	
	        }
	       }
	    };
	   elements[i].oninput = function(e) {
	        e.target.setCustomValidity(msg);
	    };
	}

	$(window).scroll(function(){
        
        if ($('#about').isOnScreen()){
            $('#valores').addClass('animated fadeInRight').show();
        }
        
        if ($('#services').isOnScreen()){
	        $('#factory').addClass('animated zoomIn').show();
	        $('#bottles').addClass('animated zoomIn').show();
        }
        
        if ($('#support').isOnScreen()){
	        $('#support1').addClass('animated fadeInUpBig').show();
	        $('#support2').addClass('animated fadeInUpBig').show();
	        $('#support3').addClass('animated fadeInUpBig').show();
        }
        
        if ($('#projects').isOnScreen()){
	        $('.projects').addClass('animated fadeInRightBig').show();
        }
        
        if ($('#contacts').isOnScreen()){
	        $('#map').addClass('animated fadeInLeftBig').show();
        }
        
    });

});

//Jquery INVIEW
$.fn.isOnScreen = function(x, y){
    
    if(x == null || typeof x == 'undefined') x = 1;
    if(y == null || typeof y == 'undefined') y = 1;
    
    var win = $(window);
    
    var viewport = {
        top : win.scrollTop(),
        left : win.scrollLeft()
    };
    viewport.right = viewport.left + win.width();
    viewport.bottom = viewport.top + win.height();
    
    var height = this.outerHeight();
    var width = this.outerWidth();
 
    if(!width || !height){
        return false;
    }
    
    var bounds = this.offset();
    bounds.right = bounds.left + width;
    bounds.bottom = bounds.top + height;
    
    var visible = (!(viewport.right < bounds.left || viewport.left > bounds.right || viewport.bottom < bounds.top || viewport.top > bounds.bottom));
    
    if(!visible){
        return false;   
    }
    
    var deltas = {
        top : Math.min( 1, ( bounds.bottom - viewport.top ) / height),
        bottom : Math.min(1, ( viewport.bottom - bounds.top ) / height),
        left : Math.min(1, ( bounds.right - viewport.left ) / width),
        right : Math.min(1, ( viewport.right - bounds.left ) / width)
    };
    
    return (deltas.left * deltas.right) >= x && (deltas.top * deltas.bottom) >= y;
    
};


//	Center Modals
function centerModals() {
	$('.modal').each(function(i) {
		var $clone = $(this).clone().css('display', 'block').appendTo('body');
		var top = Math.round(($clone.height() - $clone.find('.modal-content').height()) / 2);
		top = top > 0 ? top : 0;
		$clone.remove();
		$(this).find('.modal-content').css("margin-top", top);
	});
}
$('.modal').on('show.bs.modal', centerModals);
$(window).on('resize', centerModals);

function isNumberKey(evt){
	var charCode = (evt.which) ? evt.which : event.keyCode
	if (charCode > 31 && (charCode < 48 || charCode > 57))
	return false;
	return true;
}